function K0 = PZBAInitialPoint(sub1, Datas, parameters, methods)




%K0 =  speye(parameters.data.numofgene, parameters.transform.dimTransformedSpace);
%K0 = sub1.s * Datas.B.eigenvectors(:,end-M+1: end);
end