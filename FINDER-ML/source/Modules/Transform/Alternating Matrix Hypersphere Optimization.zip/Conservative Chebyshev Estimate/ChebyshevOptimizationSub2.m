function [output] = ChebyshevOptimizationSub2(X, Datas, parameters, methods)

%outputs a struct containing data which does change from iteration to
%iteration in the constrained optimization of the Class A Chebyshev bound

end