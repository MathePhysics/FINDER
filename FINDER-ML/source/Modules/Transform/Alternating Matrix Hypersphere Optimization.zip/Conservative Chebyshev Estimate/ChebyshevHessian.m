function [H] = ChebyshevHessian(X, lambda, Datas, parameters, methods)

%Computes the Hessian matrix of the lagrangian of the ChebyshevObjective
%function


end